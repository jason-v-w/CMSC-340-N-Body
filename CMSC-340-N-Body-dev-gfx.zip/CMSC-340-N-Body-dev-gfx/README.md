# CMSC-340-N-Body
A project to simulate and graphically display bodies interacting gravitationally
