#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>


/* Main method */
int main(int argc, char **argv) {

	return 0;
}
		